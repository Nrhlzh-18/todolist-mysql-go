# Bootstrap - Todo Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/paulj05hua/pen/LYGLJYQ](https://codepen.io/paulj05hua/pen/LYGLJYQ).

